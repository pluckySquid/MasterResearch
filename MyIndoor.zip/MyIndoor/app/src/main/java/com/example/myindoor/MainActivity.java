package com.example.myindoor;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;


import android.app.Activity;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.widget.TextView;


import java.sql.*;
import java.time.LocalTime;
import java.util.Calendar;
import java.util.Random;

public class MainActivity extends Activity implements SensorEventListener {

    private TextView xText, yText, zText;
    private Sensor mySensor;
    private SensorManager SM;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        SM = (SensorManager) getSystemService(SENSOR_SERVICE);

        //acceleration Sensor
        mySensor = SM.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        SM.registerListener(this, mySensor, 100);

        //assign TestView
        xText = (TextView)findViewById(R.id.xText );
        yText = (TextView)findViewById(R.id.yText);
        zText = (TextView)findViewById(R.id.zText);




        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        java.sql.Timestamp timestamp = new java.sql.Timestamp(System.currentTimeMillis());

        xText.setText("X     " + event.values[0]);
        yText.setText("Y     " + event.values[1]);
        zText.setText("Z     " + event.values[2] + "   time: "+timestamp);
        writeToDatabase(event.values[0], event.values[1],event.values[2], timestamp);
        //System.out.println("sdfdsdsfsdfd");

    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        //not in used
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }


    public void writeToDatabase(double xText, double yText, double zText, java.sql.Timestamp timestamp)
    {
        try
        {
            // create a mysql database connection
            //String myDriver = "org.gjt.mm.mysql.Driver";
            String myUrl = "jdbc:mysql://127.0.0.1:3306/accelerationdatabase";
            //Class.forName(myDriver);

            Connection conn = DriverManager.getConnection(myUrl, "root", "yunshu");
            Statement myStmt = conn.createStatement();

            //ResultSet myRs =  myStmt.executeQuery("select * from acc2");
            // create a sql date object so we can use it in our INSERT statement
            //long time = System.currentTimeMillis();
            //System.out.println(time);
            //java.sql.Timestamp timestamp = new java.sql.Timestamp(time);
           // System.out.println(timestamp);
            String sql = "";
            //Random rand = new Random();
            // String currentTime = "2019-3-2 " + time;
            //for(long i = timestamp; i < timestamp +1000; i=System.currentTimeMillis()) {
               // timestamp = new java.sql.Timestamp(i);
                //System.out.println( timestamp);
                double vx = xText;
                double vy = yText;
                double vz = zText;
                sql = "insert into acc2 " + "(t, accx, accy, accz)" + "values ('"+timestamp+"', " + vx + ", "+vy +", "+ vz +")";
                myStmt.execute(sql);
                //time = System.currentTimeMillis();
                //timestamp = new java.sql.Timestamp(time);
               // System.out.println(timestamp);

           // }

            // while(myRs.next()) {
            //	  System.out.println(myRs.getDate("phoneTime") +"X: "+ myRs.getFloat("acx") + ", Y: " + myRs.getFloat("acy") + ", Z: " + myRs.getFloat("acz"));
            //}

            conn.close();
        }
        catch (Exception e)
        {
            System.err.println("Got an exception!");
            System.err.println(e.getMessage());
        }
    }
}
