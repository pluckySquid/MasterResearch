package com.example.indoorlocalization;

import android.os.AsyncTask;
import android.os.Bundle;

import android.view.View;
import android.view.Menu;
import android.view.MenuItem;


import android.app.Activity;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.widget.EditText;
import android.widget.TextView;

import java.io.*;
import java.net.*;
import java.sql.*;
import java.time.LocalTime;
import java.util.Calendar;
import java.util.Random;

public class MainActivity extends Activity implements SensorEventListener {

    private TextView xText, yText, zText, aText;
    private Sensor mySensor;
    private SensorManager SM;
    private Socket clientSocket = null;
    private EditText el;
    private PrintWriter writer;
    private String IPAddress;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        el = (EditText)findViewById( R.id.ipText );










        SM = (SensorManager) getSystemService(SENSOR_SERVICE);

        //acceleration Sensor
        mySensor = SM.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        SM.registerListener(this, mySensor, 100);

        //assign TestView
        xText = (TextView)findViewById(R.id.xText );
        yText = (TextView)findViewById(R.id.yText);
        zText = (TextView)findViewById(R.id.zText);
        aText = (TextView)findViewById(R.id.aText);

    }

    @Override
    public void onSensorChanged(SensorEvent event){
        java.sql.Timestamp timestamp = new java.sql.Timestamp(System.currentTimeMillis());

        xText.setText("X     " + event.values[0]);
        yText.setText("Y     " + event.values[1]);
        zText.setText("Z     " + event.values[2] + "   time: "+timestamp);
        BackgroundTask b = new BackgroundTask();
        String xT = String.valueOf(event.values[0]);
        String yT = String.valueOf(event.values[1]);
        String zT = String.valueOf(event.values[2]);
        //String time = timestamp.toString();
        b.execute(xT);
        b.execute( yT );
        b.execute( zT );
        //b.execute( time );
        //int o = writeToServer(event.values[0], event.values[1],event.values[2]);
        //aText.setText("a     " + o);
        //System.out.println("sdfdsdsfsdfd");

    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        //not in used
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }


    class BackgroundTask extends AsyncTask<String, Void, Void> {

        Socket s;
        PrintWriter writer;

        @Override
        protected Void doInBackground(String... voids) {
            try {
                String accelerometer = voids[0];
                s = new Socket( IPAddress, 5110 );
                writer = new PrintWriter( s.getOutputStream() );
                writer.write( accelerometer );
                writer.flush();
                writer.close();
                s.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

    }
        public void sendIP(View v){
            String message = el.getText().toString();
            sendIPAdress b1 = new sendIPAdress();
            b1.execute( message );
        }

        class sendIPAdress extends AsyncTask<String, Void, Void>
        {
            Socket s;
            PrintWriter writer;

            @Override
            protected Void doInBackground(String... voids) {
                 IPAddress = "";
                try {
                    IPAddress =  voids[0];
                    s = new Socket(IPAddress, 5110 );
                    writer = new PrintWriter(s.getOutputStream());
                    writer.write( IPAddress );
                    writer.flush();
                    writer.close();
                }
                catch (IOException e){
                    e.printStackTrace();
                }
                return null;
            }
        }



}